package com.novastack.vaultfile

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import android.os.StatFs

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "vaultfile/storage").setMethodCallHandler { call, result ->
            if (call.method == "storageInfo") {
                val stat = StatFs(android.os.Environment.getExternalStorageDirectory().path)
                val block = stat.blockSizeLong
                result.success(mapOf("total" to stat.blockCountLong * block, "free" to stat.availableBlocksLong * block))
            } else result.notImplemented()
        }
    }
}
