import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:audioplayers/audioplayers.dart';
import 'package:archive/archive.dart';
import 'package:crypto/crypto.dart';
import 'package:encrypt/encrypt.dart' as cipher;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/rendering.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:video_player/video_player.dart';
import 'package:share_plus/share_plus.dart';

void main() => runApp(const VaultFileApp());
const ink = Color(0xFF10212B),
    teal = Color(0xFF13B8A6),
    canvas = Color(0xFFF6F8F7);
final appTheme = ValueNotifier<String>('light');
const editableExtensions = <String>{
  'txt',
  'db',
  'md',
  'log',
  'ini',
  'cfg',
  'conf',
  'config',
  'env',
  'properties',
  'toml',
  'yaml',
  'yml',
  'xml',
  'json',
  'csv',
  'tsv',
  'html',
  'htm',
  'css',
  'scss',
  'sass',
  'js',
  'mjs',
  'cjs',
  'jsx',
  'ts',
  'tsx',
  'php',
  'py',
  'java',
  'c',
  'h',
  'cpp',
  'hpp',
  'cs',
  'go',
  'rs',
  'rb',
  'swift',
  'kt',
  'dart',
  'sql',
  'sh',
  'bash',
  'ps1',
  'bat',
  'cmd',
  'lua',
  'pl',
  'r',
  'ex',
  'exs',
  'vue',
  'svelte',
  'diff',
  'patch',
  'tex',
  'rtf',
  'svg',
  'graphql',
  'gql',
  'proto',
  'ipynb',
  'lock',
  'gitignore',
  'gitattributes',
  'editorconfig',
  'dockerignore',
  'makefile',
  'dockerfile',
};

class VaultFileApp extends StatelessWidget {
  const VaultFileApp({super.key});
  @override
  Widget build(BuildContext context) => ValueListenableBuilder<String>(
    valueListenable: appTheme,
    builder: (context, selectedTheme, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'VaultFile',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        scaffoldBackgroundColor: selectedTheme == 'gray'
            ? const Color(0xFFE5E7EB)
            : selectedTheme == 'dark'
            ? const Color(0xFF12181C)
            : selectedTheme == 'glass'
            ? Colors.transparent
            : canvas,
        colorScheme: ColorScheme.fromSeed(
          seedColor: teal,
        ).copyWith(primary: ink, secondary: teal),
        cardTheme: CardThemeData(
          color: selectedTheme == 'glass'
              ? Colors.white.withValues(alpha: .48)
              : Colors.white,
          elevation: selectedTheme == 'glass' ? 0 : 1,
        ),
        navigationBarTheme: NavigationBarThemeData(
          backgroundColor: selectedTheme == 'glass'
              ? Colors.white.withValues(alpha: .35)
              : Colors.white,
        ),
        appBarTheme: AppBarTheme(
          backgroundColor: selectedTheme == 'glass'
              ? Colors.white.withValues(alpha: .28)
              : canvas,
          surfaceTintColor: Colors.transparent,
          elevation: 0,
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: selectedTheme == 'glass'
              ? Colors.white.withValues(alpha: .45)
              : Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(14)),
            borderSide: BorderSide.none,
          ),
        ),
      ),
      darkTheme: ThemeData.dark(useMaterial3: true),
      home: const Shell(),
    ),
  );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;
  final browserKey = GlobalKey<_FileBrowserPageState>();
  DateTime? lastBack;
  @override
  void initState() {
    super.initState();
    appTheme.addListener(_themeChanged);
  }

  @override
  void dispose() {
    appTheme.removeListener(_themeChanged);
    super.dispose();
  }

  void _themeChanged() {
    if (mounted) setState(() {});
  }

  void _handleBack() {
    final navigator = Navigator.of(context);
    if (tab == 0 && browserKey.currentState?.goBackFromSystem() == true) return;
    if (navigator.canPop()) {
      navigator.pop();
      return;
    }
    final now = DateTime.now();
    if (lastBack != null &&
        now.difference(lastBack!) < const Duration(seconds: 2)) {
      showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Sair do VaultFile?'),
          content: const Text('Deseja fechar o aplicativo?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Continuar usando'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Sair'),
            ),
          ],
        ),
      ).then((yes) {
        if (yes == true) exit(0);
      });
    } else {
      lastBack = now;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pressione voltar novamente para sair.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => PopScope(
    canPop: false,
    onPopInvokedWithResult: (_, __) => _handleBack(),
    child: Stack(
      children: [
        if (appTheme.value == 'glass')
          Positioned.fill(
            child: DecoratedBox(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFFE1F7F3),
                    Color(0xFFE5E8FF),
                    Color(0xFFFFE8F2),
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: BackdropFilter(
                filter: ui.ImageFilter.blur(sigmaX: 18, sigmaY: 18),
                child: const SizedBox.expand(),
              ),
            ),
          ),
        Scaffold(
          backgroundColor: appTheme.value == 'glass'
              ? Colors.transparent
              : null,
          body: IndexedStack(
            index: tab,
            children: [
              FileBrowserPage(key: browserKey),
              const ConnectionsPage(),
              const ToolsPage(),
            ],
          ),
          bottomNavigationBar: NavigationBar(
            selectedIndex: tab,
            onDestinationSelected: (i) => setState(() => tab = i),
            backgroundColor: appTheme.value == 'glass'
                ? Colors.white.withValues(alpha: .35)
                : Colors.white,
            indicatorColor: const Color(0xFFD8F5F0),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.folder_copy_outlined),
                selectedIcon: Icon(Icons.folder_copy),
                label: 'Arquivos',
              ),
              NavigationDestination(
                icon: Icon(Icons.hub_outlined),
                selectedIcon: Icon(Icons.hub),
                label: 'Conexões',
              ),
              NavigationDestination(
                icon: Icon(Icons.tune_outlined),
                selectedIcon: Icon(Icons.tune),
                label: 'Ajustes',
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

enum ViewMode { list, grid, details }

class FileBrowserPage extends StatefulWidget {
  const FileBrowserPage({super.key});
  @override
  State<FileBrowserPage> createState() => _FileBrowserPageState();
}

class _FileBrowserPageState extends State<FileBrowserPage>
    with WidgetsBindingObserver {
  String? path;
  String? fallbackPath;
  List<FileSystemEntity> entries = [];
  bool loading = true,
      usingFallback = false,
      searching = false,
      showHidden = false,
      selecting = false;
  final selected = <String>{};
  String query = '';
  ViewMode mode = ViewMode.grid;
  final search = TextEditingController();
  Future<Map<dynamic, dynamic>>? storageInfo;
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    storageInfo = const MethodChannel('vaultfile/storage')
        .invokeMethod<Map<dynamic, dynamic>>('storageInfo')
        .then((value) => value ?? <dynamic, dynamic>{});
    _load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    search.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    showHidden = prefs.getBool('show_hidden') ?? false;
    if (mounted) setState(() => loading = true);
    try {
      final desired = path ?? '/storage/emulated/0';
      final list = await Directory(desired).list(followLinks: false).toList();
      path = desired;
      usingFallback = false;
      _setEntries(list);
    } catch (_) {
      try {
        final dir = Directory(
          fallbackPath ??
              (await getExternalStorageDirectory())?.path ??
              (await getApplicationDocumentsDirectory()).path,
        );
        fallbackPath = dir.path;
        path = dir.path;
        final list = await dir.list(followLinks: false).toList();
        usingFallback = true;
        _setEntries(list);
      } catch (_) {
        if (mounted)
          setState(() {
            loading = false;
            entries = [];
          });
      }
    }
  }

  void _setEntries(List<FileSystemEntity> list) {
    list.sort((a, b) {
      final ad = a is Directory, bd = b is Directory;
      if (ad != bd) return ad ? -1 : 1;
      return _name(a).toLowerCase().compareTo(_name(b).toLowerCase());
    });
    if (mounted)
      setState(() {
        entries = list;
        loading = false;
      });
  }

  String _name(FileSystemEntity e) => e.path.split(Platform.pathSeparator).last;
  List<FileSystemEntity> get visible => entries.where((e) {
    final name = _name(e);
    return (showHidden || !name.startsWith('.')) &&
        (query.isEmpty || name.toLowerCase().contains(query.toLowerCase()));
  }).toList();
  List<FileSystemEntity> get selectedEntities =>
      entries.where((e) => selected.contains(e.path)).toList();
  bool get atRoot => path == '/storage/emulated/0' || path == fallbackPath;
  bool get canGoBackFromSystem => !atRoot;
  bool goBackFromSystem() {
    if (!canGoBackFromSystem) return false;
    _back();
    return true;
  }

  Future<void> _requestFullAccess() async {
    await Permission.manageExternalStorage.request();
    await openAppSettings();
  }

  Future<void> _openShortcut(String target) async {
    if (await Directory(target).exists()) {
      setState(() {
        path = target;
        query = '';
        search.clear();
      });
      await _load();
    } else if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Esta pasta ainda não existe no dispositivo.'),
        ),
      );
    }
  }

  Widget _homeOverview() => FutureBuilder<Map<dynamic, dynamic>>(
    future: storageInfo,
    builder: (context, snapshot) {
      final total = (snapshot.data?['total'] as num?)?.toDouble() ?? 0;
      final free = (snapshot.data?['free'] as num?)?.toDouble() ?? 0;
      final used = total > 0 ? (total - free).clamp(0, total) : 0;
      final fraction = total > 0 ? used / total : 0.0;
      String size(double b) => b >= 1073741824
          ? '${(b / 1073741824).toStringAsFixed(1)} GB'
          : '${(b / 1048576).toStringAsFixed(0)} MB';
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Card(
            color: ink,
            child: Padding(
              padding: const EdgeInsets.all(18),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Armazenamento interno',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(
                    value: fraction,
                    minHeight: 9,
                    borderRadius: BorderRadius.circular(8),
                    backgroundColor: Colors.white24,
                    color: teal,
                  ),
                  const SizedBox(height: 9),
                  Text(
                    snapshot.hasData
                        ? '${(fraction * 100).toStringAsFixed(0)}% usado · ${size(free)} livres de ${size(total)}'
                        : 'Calculando espaço disponível...',
                    style: const TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ],
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.fromLTRB(4, 16, 4, 8),
            child: Text(
              'Acessos rápidos',
              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
            ),
          ),
          Row(
            children: [
              _shortcut(
                'Downloads',
                '/storage/emulated/0/Download',
                Icons.download_rounded,
                const Color(0xFF4778E8),
              ),
              _shortcut(
                'Imagens',
                '/storage/emulated/0/Pictures',
                Icons.photo_library_rounded,
                const Color(0xFFE77C45),
              ),
              _shortcut(
                'Vídeos',
                '/storage/emulated/0/Movies',
                Icons.video_library_rounded,
                const Color(0xFF9C5DEB),
              ),
            ],
          ),
          const SizedBox(height: 8),
        ],
      );
    },
  );

  Widget _shortcut(String label, String target, IconData icon, Color color) =>
      Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4),
          child: InkWell(
            onTap: () => _openShortcut(target),
            borderRadius: BorderRadius.circular(16),
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 4),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                children: [
                  Icon(icon, color: color, size: 29),
                  const SizedBox(height: 6),
                  Text(
                    label,
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );

  Future<void> _open(FileSystemEntity e) async {
    if (e is Directory) {
      setState(() {
        path = e.path;
        query = '';
        search.clear();
      });
      await _load();
      return;
    }
    await _fileActions(e);
  }

  Future<void> _openExternal(FileSystemEntity e) async {
    final result = await OpenFilex.open(e.path);
    if (mounted && result.type != ResultType.done)
      _toast('Nenhum aplicativo compatível encontrado.');
  }

  Future<void> _fileActions(FileSystemEntity e) async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
              child: Text(
                _name(e),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.open_in_new_rounded),
              title: const Text('Abrir'),
              onTap: () {
                Navigator.pop(context);
                _openExternal(e);
              },
            ),
            if (e is File && _name(e).toLowerCase().endsWith('.zip'))
              ListTile(
                leading: const Icon(Icons.unarchive_rounded, color: teal),
                title: const Text('Deszipar / extrair ZIP'),
                onTap: () {
                  Navigator.pop(context);
                  _extractZip(e);
                },
              ),
            if (e is File && _name(e).toLowerCase().endsWith('.zip'))
              ListTile(
                leading: const Icon(Icons.folder_zip_rounded),
                title: const Text('Abrir ZIP com outro aplicativo'),
                onTap: () {
                  Navigator.pop(context);
                  _openExternal(e);
                },
              ),
            if (e is File && _name(e).toLowerCase().endsWith('.rar'))
              ListTile(
                leading: const Icon(Icons.unarchive_rounded, color: teal),
                title: const Text('UnRAR / extrair RAR'),
                onTap: () {
                  Navigator.pop(context);
                  _openExternal(e);
                },
              ),
            if (e is File && _name(e).toLowerCase().endsWith('.7z'))
              ListTile(
                leading: const Icon(Icons.unarchive_rounded, color: teal),
                title: const Text('Extrair 7Z com outro aplicativo'),
                onTap: () {
                  Navigator.pop(context);
                  _openExternal(e);
                },
              ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline_rounded,
                color: Colors.red,
              ),
              title: const Text('Apagar'),
              onTap: () {
                Navigator.pop(context);
                _delete(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit_rounded),
              title: const Text('Editar'),
              onTap: () {
                Navigator.pop(context);
                _editFile(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.archive_rounded),
              title: const Text('Zipar'),
              onTap: () {
                Navigator.pop(context);
                _zip(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_rounded),
              title: const Text('Compartilhar'),
              onTap: () {
                Navigator.pop(context);
                _share(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.check_box_outlined),
              title: const Text('Selecionar'),
              onTap: () {
                Navigator.pop(context);
                _toggleSelection(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Renomear'),
              onTap: () {
                Navigator.pop(context);
                _rename(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: const Text('Detalhes'),
              onTap: () {
                Navigator.pop(context);
                _details(e);
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _editFile(FileSystemEntity e) async {
    final ext = _name(e).split('.').last.toLowerCase();
    if (ext == 'zip') {
      await _extractZip(File(e.path));
      return;
    }
    if ([
      'jpg',
      'jpeg',
      'png',
      'gif',
      'webp',
      'bmp',
      'tif',
      'tiff',
      'heic',
      'heif',
      'avif',
      'ico',
    ].contains(ext)) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => ImageEditorPage(file: File(e.path))),
      );
      await _load();
      return;
    }
    if (['mp4', 'mov', 'mkv', 'avi'].contains(ext)) {
      await Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => VideoPreviewPage(file: File(e.path), title: _name(e)),
        ),
      );
      return;
    }
    if (editableExtensions.contains(ext)) {
      await Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => TextEditorPage(file: File(e.path))),
      );
      await _load();
      return;
    }
    final result = await OpenFilex.open(e.path);
    if (mounted && result.type != ResultType.done)
      _toast('Nenhum editor compatível foi encontrado.');
  }

  void _toggleSelection(FileSystemEntity e) {
    setState(() {
      selecting = true;
      selected.contains(e.path)
          ? selected.remove(e.path)
          : selected.add(e.path);
      if (selected.isEmpty) selecting = false;
    });
  }

  Future<void> _rename(FileSystemEntity e) async {
    final c = TextEditingController(text: _name(e));
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Renomear'),
        content: TextField(controller: c, autofocus: true),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: const Text('Salvar'),
          ),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    try {
      await e.rename('${Directory(e.path).parent.path}/$name');
      await _load();
    } catch (err) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Não foi possível renomear: $err')),
        );
    }
  }

  Future<void> _move(FileSystemEntity e) async {
    final c = TextEditingController(text: path ?? '/storage/emulated/0');
    final destination = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Mover para'),
        content: TextField(
          controller: c,
          decoration: const InputDecoration(labelText: 'Pasta de destino'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: const Text('Mover'),
          ),
        ],
      ),
    );
    if (destination == null || destination.isEmpty) return;
    try {
      await e.rename('$destination/${_name(e)}');
      await _load();
    } catch (err) {
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Não foi possível mover: $err')));
    }
  }

  Future<void> _share(FileSystemEntity e) async => SharePlus.instance.share(
    ShareParams(files: [XFile(e.path)], text: _name(e)),
  );

  Future<void> _zip(FileSystemEntity e) async {
    final archive = Archive();
    void add(FileSystemEntity item, String name) {
      if (item is File) {
        final bytes = item.readAsBytesSync();
        archive.addFile(ArchiveFile(name, bytes.length, bytes));
      } else if (item is Directory) {
        for (final child in item.listSync(followLinks: false))
          add(child, '$name/${_name(child)}');
      }
    }

    add(e, _name(e));
    final bytes = ZipEncoder().encode(archive);
    if (bytes == null) return;
    final out = File('${Directory(e.path).parent.path}/${_name(e)}.zip');
    await out.writeAsBytes(bytes, flush: true);
    await _load();
    if (mounted)
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('ZIP criado: ${_name(out)}')));
  }

  Future<void> _batchShare() async {
    for (final e in selectedEntities) {
      if (e is File) await _share(e);
    }
  }

  Future<void> _batchZip() async {
    for (final e in selectedEntities) await _zip(e);
    setState(() {
      selected.clear();
      selecting = false;
    });
  }

  Future<String?> _password(String title, {bool confirm = false}) async {
    final c = TextEditingController(), d = TextEditingController();
    return showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(title),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: c,
              obscureText: true,
              autofocus: true,
              decoration: const InputDecoration(labelText: 'Senha'),
            ),
            if (confirm)
              TextField(
                controller: d,
                obscureText: true,
                decoration: const InputDecoration(labelText: 'Confirmar senha'),
              ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              if (c.text.isEmpty || (confirm && c.text != d.text)) return;
              Navigator.pop(context, c.text);
            },
            child: const Text('Continuar'),
          ),
        ],
      ),
    );
  }

  Future<void> _encryptFile(FileSystemEntity e) async {
    if (e is! File) return;
    final password = await _password('Criptografar arquivo', confirm: true);
    if (password == null) return;
    final keyBytes = sha256.convert(utf8.encode(password)).bytes;
    final iv = cipher.IV.fromSecureRandom(16);
    final box = cipher.Encrypter(
      cipher.AES(
        cipher.Key(Uint8List.fromList(keyBytes)),
        mode: cipher.AESMode.cbc,
      ),
    );
    final encrypted = box.encryptBytes(await e.readAsBytes(), iv: iv);
    final out = File('${e.path}.vault');
    await out.writeAsBytes([...iv.bytes, ...encrypted.bytes], flush: true);
    await _load();
    if (mounted) _toast('Arquivo criptografado: ${_name(out)}');
  }

  Future<void> _decryptFile(FileSystemEntity e) async {
    if (e is! File) return;
    final password = await _password('Descriptografar arquivo');
    if (password == null) return;
    try {
      final raw = await e.readAsBytes();
      final iv = cipher.IV(Uint8List.fromList(raw.sublist(0, 16)));
      final key = cipher.Key(
        Uint8List.fromList(sha256.convert(utf8.encode(password)).bytes),
      );
      final box = cipher.Encrypter(cipher.AES(key, mode: cipher.AESMode.cbc));
      final plain = box.decryptBytes(
        cipher.Encrypted(Uint8List.fromList(raw.sublist(16))),
        iv: iv,
      );
      final base = e.path.endsWith('.vault')
          ? e.path.substring(0, e.path.length - 6)
          : '${e.path}.decrypted';
      final out = File(base);
      await out.writeAsBytes(plain, flush: true);
      await _load();
      if (mounted) _toast('Arquivo descriptografado: ${_name(out)}');
    } catch (_) {
      if (mounted) _toast('Senha incorreta ou arquivo criptografado inválido.');
    }
  }

  Future<void> _extractZip(File e) async {
    try {
      final decoded = ZipDecoder().decodeBytes(await e.readAsBytes());
      final dir = Directory(
        '${e.path.substring(0, e.path.length - 4)}_extraido',
      );
      await dir.create();
      for (final item in decoded) {
        final out = File('${dir.path}/${item.name}');
        if (item.isFile) {
          await out.parent.create(recursive: true);
          await out.writeAsBytes(item.content as List<int>);
        } else {
          await Directory(out.path).create(recursive: true);
        }
      }
      await _load();
      if (mounted) _toast('ZIP extraído em ${_name(dir)}');
    } catch (err) {
      if (mounted) _toast('Não foi possível abrir o ZIP: $err');
    }
  }

  Future<void> _deleteSelected() async {
    final items = selectedEntities.toList();
    if (items.isEmpty) return;
    for (final e in items) {
      try {
        if (e is Directory)
          await e.delete(recursive: true);
        else
          await File(e.path).delete();
      } catch (_) {}
    }
    setState(() {
      selected.clear();
      selecting = false;
    });
    await _load();
  }

  void _back() {
    if (atRoot) return;
    final parent = Directory(path!).parent.path;
    setState(() => path = parent);
    _load();
  }

  Future<void> _folder() async {
    final c = TextEditingController();
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Nova pasta'),
        content: TextField(
          controller: c,
          autofocus: true,
          decoration: const InputDecoration(hintText: 'Nome'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, c.text.trim()),
            child: const Text('Criar'),
          ),
        ],
      ),
    );
    if (name == null || name.isEmpty) return;
    try {
      await Directory('${path!}/$name').create();
      await _load();
    } catch (_) {
      _toast('Não foi possível criar a pasta.');
    }
  }

  Future<void> _delete(FileSystemEntity e) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Excluir item?'),
        content: Text('“${_name(e)}” será removido.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      if (e is Directory)
        await e.delete(recursive: true);
      else
        await File(e.path).delete();
      await _load();
    } catch (_) {
      _toast('Não foi possível excluir este item.');
    }
  }

  void _toast(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  Color _color(FileSystemEntity e) {
    if (e is Directory) return const Color(0xFFFFB84D);
    final x = _name(e).split('.').last.toLowerCase();
    if (x == 'pdf') return const Color(0xFFE76969);
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].contains(x))
      return const Color(0xFF8C7CF5);
    if (['mp4', 'mkv', 'mov'].contains(x)) return const Color(0xFF5D9CEC);
    if (['xls', 'xlsx', 'csv'].contains(x)) return const Color(0xFF42B883);
    return teal;
  }

  IconData _icon(FileSystemEntity e) {
    if (e is Directory) return Icons.folder_rounded;
    final x = _name(e).split('.').last.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].contains(x))
      return Icons.image_rounded;
    if (['mp4', 'mkv', 'mov'].contains(x)) return Icons.movie_rounded;
    if (x == 'pdf') return Icons.picture_as_pdf_rounded;
    if (['txt', 'md', 'json', 'csv', 'xml', 'log'].contains(x))
      return Icons.article_rounded;
    if (['zip', 'rar', '7z'].contains(x)) return Icons.archive_rounded;
    if (x == 'apk') return Icons.android_rounded;
    return Icons.insert_drive_file_rounded;
  }

  String _detail(FileSystemEntity e) {
    if (e is Directory) return 'Pasta · diretório';
    try {
      final n = File(e.path).lengthSync();
      final ext = _name(e).contains('.')
          ? _name(e).split('.').last.toUpperCase()
          : 'sem extensão';
      final size = n < 1048576
          ? '${(n / 1024).toStringAsFixed(0)} KB'
          : '${(n / 1048576).toStringAsFixed(1)} MB';
      return '$ext · $size';
    } catch (_) {
      return 'Arquivo';
    }
  }

  void _details(FileSystemEntity e) {
    final stat = e.statSync();
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(_name(e)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(e is Directory ? 'Tipo: Pasta' : 'Tipo: Arquivo'),
            const SizedBox(height: 8),
            Text(
              'Extensão: ${e is Directory ? '—' : (_name(e).contains('.') ? '.${_name(e).split('.').last}' : 'sem extensão')}',
            ),
            const SizedBox(height: 8),
            Text('Tamanho: ${_detail(e)}'),
            const SizedBox(height: 8),
            Text('Caminho: ${e.path}'),
            const SizedBox(height: 8),
            Text('Modificado: ${stat.modified}'),
            const SizedBox(height: 8),
            Text('Acesso: ${stat.modeString}'),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _menu(FileSystemEntity e) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      builder: (_) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.open_in_new_rounded),
              title: const Text('Abrir'),
              onTap: () {
                Navigator.pop(context);
                _open(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.info_outline_rounded),
              title: const Text('Detalhes'),
              onTap: () {
                Navigator.pop(context);
                _details(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_rename_outline),
              title: const Text('Renomear'),
              onTap: () {
                Navigator.pop(context);
                _rename(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.drive_file_move_outline),
              title: const Text('Mover para outra pasta'),
              onTap: () {
                Navigator.pop(context);
                _move(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.share_rounded),
              title: const Text('Compartilhar'),
              onTap: () {
                Navigator.pop(context);
                _share(e);
              },
            ),
            ListTile(
              leading: const Icon(Icons.archive_rounded),
              title: const Text('Compactar em ZIP'),
              onTap: () {
                Navigator.pop(context);
                _zip(e);
              },
            ),
            if (e is File && _name(e).toLowerCase().endsWith('.vault'))
              ListTile(
                leading: const Icon(Icons.lock_open_rounded),
                title: const Text('Descriptografar'),
                onTap: () {
                  Navigator.pop(context);
                  _decryptFile(e);
                },
              ),
            if (e is File && !_name(e).toLowerCase().endsWith('.vault'))
              ListTile(
                leading: const Icon(Icons.lock_rounded),
                title: const Text('Criptografar com senha'),
                onTap: () {
                  Navigator.pop(context);
                  _encryptFile(e);
                },
              ),
            ListTile(
              leading: const Icon(Icons.open_in_new_rounded),
              title: const Text('Abrir com outro aplicativo'),
              onTap: () {
                Navigator.pop(context);
                OpenFilex.open(e.path);
              },
            ),
            ListTile(
              leading: const Icon(
                Icons.delete_outline_rounded,
                color: Colors.red,
              ),
              title: const Text('Excluir', style: TextStyle(color: Colors.red)),
              onTap: () {
                Navigator.pop(context);
                _delete(e);
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: Column(
      children: [
        _header(),
        if (atRoot && !searching) _homeOverview(),
        if (usingFallback)
          Material(
            color: const Color(0xFFFFF1D6),
            child: InkWell(
              onTap: _requestFullAccess,
              child: const Padding(
                padding: EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                child: Row(
                  children: [
                    Icon(Icons.info_outline_rounded, size: 18),
                    SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        'Modo seguro: exibindo a pasta acessível. Toque para liberar o armazenamento completo.',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                    Icon(Icons.chevron_right_rounded),
                  ],
                ),
              ),
            ),
          ),
        Expanded(
          child: loading
              ? const Center(child: CircularProgressIndicator(color: teal))
              : RefreshIndicator(
                  onRefresh: _load,
                  child: visible.isEmpty
                      ? ListView(
                          children: const [
                            SizedBox(height: 140),
                            Center(child: Text('Esta pasta está vazia')),
                          ],
                        )
                      : mode == ViewMode.grid
                      ? GridView.builder(
                          padding: const EdgeInsets.all(14),
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 3,
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: .88,
                              ),
                          itemCount: visible.length,
                          itemBuilder: (_, i) => _GridItem(
                            entity: visible[i],
                            name: _name(visible[i]),
                            detail: _detail(visible[i]),
                            selected: selected.contains(visible[i].path),
                            icon: _icon(visible[i]),
                            color: _color(visible[i]),
                            onTap: () => selecting
                                ? _toggleSelection(visible[i])
                                : _open(visible[i]),
                            onLong: () => _toggleSelection(visible[i]),
                          ),
                        )
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 90),
                          itemCount: visible.length,
                          itemBuilder: (_, i) => _ListItem(
                            entity: visible[i],
                            name: _name(visible[i]),
                            detail: mode == ViewMode.details
                                ? '${_detail(visible[i])} · ${visible[i].path}'
                                : _detail(visible[i]),
                            selected: selected.contains(visible[i].path),
                            icon: _icon(visible[i]),
                            color: _color(visible[i]),
                            onTap: () => selecting
                                ? _toggleSelection(visible[i])
                                : _open(visible[i]),
                            onMore: () => _menu(visible[i]),
                          ),
                        ),
                ),
        ),
      ],
    ),
  );
  Widget _header() => Padding(
    padding: const EdgeInsets.fromLTRB(14, 10, 10, 4),
    child: Row(
      children: [
        IconButton(
          onPressed: atRoot ? null : _back,
          icon: const Icon(Icons.arrow_back_rounded),
        ),
        Expanded(
          child: searching
              ? TextField(
                  controller: search,
                  autofocus: true,
                  onChanged: (v) => setState(() => query = v),
                  decoration: const InputDecoration(
                    hintText: 'Pesquisar',
                    isDense: true,
                  ),
                )
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Arquivos',
                      style: TextStyle(
                        fontSize: 21,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    Text(
                      path?.replaceFirst(
                            '/storage/emulated/0',
                            'Armazenamento interno',
                          ) ??
                          'Armazenamento interno',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 12,
                        color: Color(0xFF6D7B80),
                      ),
                    ),
                  ],
                ),
        ),
        IconButton(
          onPressed: () => setState(() {
            searching = !searching;
            if (!searching) {
              query = '';
              search.clear();
            }
          }),
          icon: Icon(searching ? Icons.close : Icons.search),
        ),
        IconButton(
          onPressed: () => setState(() {
            selecting = !selecting;
            if (!selecting) selected.clear();
          }),
          tooltip: 'Selecionar vários',
          icon: Icon(
            selecting ? Icons.check_box : Icons.check_box_outline_blank,
          ),
        ),
        if (selecting)
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'share') _batchShare();
              if (v == 'zip') _batchZip();
              if (v == 'delete') _deleteSelected();
            },
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: 'share',
                child: Text('Compartilhar selecionados'),
              ),
              PopupMenuItem(
                value: 'zip',
                child: Text('Compactar selecionados em ZIP'),
              ),
              PopupMenuItem(
                value: 'delete',
                child: Text('Excluir selecionados'),
              ),
            ],
          ),
        PopupMenuButton<ViewMode>(
          icon: const Icon(Icons.view_module_outlined),
          onSelected: (v) => setState(() => mode = v),
          itemBuilder: (_) => const [
            PopupMenuItem(value: ViewMode.list, child: Text('Lista')),
            PopupMenuItem(value: ViewMode.grid, child: Text('Quadrados')),
            PopupMenuItem(
              value: ViewMode.details,
              child: Text('Lista detalhada'),
            ),
          ],
        ),
        IconButton(
          onPressed: _folder,
          icon: const Icon(Icons.create_new_folder_outlined),
        ),
        IconButton(onPressed: _load, icon: const Icon(Icons.refresh_rounded)),
      ],
    ),
  );
}

class _ListItem extends StatelessWidget {
  final FileSystemEntity entity;
  final String name, detail;
  final bool selected;
  final IconData icon;
  final Color color;
  final VoidCallback onTap, onMore;
  const _ListItem({
    required this.entity,
    required this.name,
    required this.detail,
    required this.selected,
    required this.icon,
    required this.color,
    required this.onTap,
    required this.onMore,
  });
  @override
  Widget build(BuildContext context) => ListTile(
    tileColor: selected ? const Color(0xFFDDF6F1) : null,
    onTap: onTap,
    onLongPress: onMore,
    contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 2),
    leading: Container(
      width: 48,
      height: 48,
      decoration: BoxDecoration(
        color: color.withValues(alpha: .14),
        borderRadius: BorderRadius.circular(15),
      ),
      child: Icon(icon, color: color),
    ),
    title: Text(
      name,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
    ),
    subtitle: Text(
      detail,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: const TextStyle(fontSize: 11, color: Color(0xFF7A878B)),
    ),
    trailing: IconButton(
      onPressed: onMore,
      icon: const Icon(Icons.more_vert_rounded),
    ),
  );
}

class _GridItem extends StatelessWidget {
  final FileSystemEntity entity;
  final String name, detail;
  final bool selected;
  final IconData icon;
  final Color color;
  final VoidCallback onTap, onLong;
  const _GridItem({
    required this.entity,
    required this.name,
    required this.detail,
    required this.selected,
    required this.icon,
    required this.color,
    required this.onTap,
    required this.onLong,
  });
  @override
  Widget build(BuildContext context) => InkWell(
    onTap: onTap,
    onLongPress: onLong,
    borderRadius: BorderRadius.circular(18),
    child: Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: selected ? const Color(0xFFDDF6F1) : Colors.white,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 38),
          const SizedBox(height: 9),
          Text(
            name,
            maxLines: 2,
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 3),
          Text(
            detail,
            style: const TextStyle(fontSize: 10, color: Color(0xFF7A878B)),
          ),
        ],
      ),
    ),
  );
}

class TextEditorPage extends StatefulWidget {
  final File file;
  const TextEditorPage({super.key, required this.file});
  @override
  State<TextEditorPage> createState() => _TextEditorPageState();
}

class _TextEditorPageState extends State<TextEditorPage> {
  late TextEditingController controller;
  bool loading = true, saving = false, changed = false;
  @override
  void initState() {
    super.initState();
    controller = TextEditingController();
    _read();
  }

  Future<void> _read() async {
    try {
      controller.text = await widget.file.readAsString();
    } catch (_) {
      controller.text = '';
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _save() async {
    setState(() => saving = true);
    try {
      await widget.file.writeAsString(controller.text);
      changed = false;
      if (mounted)
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(const SnackBar(content: Text('Arquivo salvo.')));
    } catch (_) {
      if (mounted)
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Não foi possível salvar o arquivo.')),
        );
    }
    if (mounted) setState(() => saving = false);
  }

  bool get isHtml {
    final ext = widget.file.path.split('.').last.toLowerCase();
    return ext == 'html' || ext == 'htm';
  }

  void _preview() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => HtmlPreviewPage(
          title: widget.file.path.split('/').last,
          html: controller.text,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(
        widget.file.path.split('/').last,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
      ),
      actions: [
        if (isHtml)
          IconButton(
            onPressed: _preview,
            tooltip: 'Testar página',
            icon: const Icon(Icons.web_rounded),
          ),
        saving
            ? const Padding(
                padding: EdgeInsets.all(16),
                child: SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            : IconButton(
                onPressed: _save,
                icon: const Icon(Icons.save_rounded),
              ),
      ],
    ),
    body: loading
        ? const Center(child: CircularProgressIndicator())
        : Padding(
            padding: const EdgeInsets.all(14),
            child: TextField(
              controller: controller,
              expands: true,
              maxLines: null,
              minLines: null,
              textAlignVertical: TextAlignVertical.top,
              onChanged: (_) => changed = true,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 14),
              decoration: const InputDecoration(
                hintText: 'Comece a escrever...',
                alignLabelWithHint: true,
              ),
            ),
          ),
  );
}

class ImageEditorPage extends StatefulWidget {
  final File file;
  const ImageEditorPage({super.key, required this.file});
  @override
  State<ImageEditorPage> createState() => _ImageEditorPageState();
}

class _ImageEditorPageState extends State<ImageEditorPage> {
  final boundary = GlobalKey();
  final strokes = <List<Offset>>[];
  Color color = Colors.red;
  double width = 5;
  Future<void> save() async {
    final render =
        boundary.currentContext!.findRenderObject() as RenderRepaintBoundary;
    final image = await render.toImage(pixelRatio: 2);
    final data = await image.toByteData(format: ui.ImageByteFormat.png);
    if (data == null) return;
    final out = File('${widget.file.path}.editado.png');
    await out.writeAsBytes(data.buffer.asUint8List(), flush: true);
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Cópia salva: ${out.path.split('/').last}')),
      );
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Editar imagem'),
      actions: [
        IconButton(onPressed: save, icon: const Icon(Icons.save_rounded)),
      ],
    ),
    body: Column(
      children: [
        Expanded(
          child: Center(
            child: RepaintBoundary(
              key: boundary,
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.file(widget.file, fit: BoxFit.contain),
                  GestureDetector(
                    onPanStart: (d) =>
                        setState(() => strokes.add([d.localPosition])),
                    onPanUpdate: (d) =>
                        setState(() => strokes.last.add(d.localPosition)),
                    onPanEnd: (_) {},
                    child: CustomPaint(
                      painter: _StrokePainter(strokes, color, width),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        SafeArea(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                onPressed: () => setState(() => color = Colors.red),
                icon: Icon(Icons.circle, color: Colors.red),
              ),
              IconButton(
                onPressed: () => setState(() => color = Colors.blue),
                icon: Icon(Icons.circle, color: Colors.blue),
              ),
              IconButton(
                onPressed: () => setState(() => color = Colors.black),
                icon: Icon(Icons.circle, color: Colors.black),
              ),
              IconButton(
                onPressed: () => setState(() => width = width == 5 ? 14 : 5),
                icon: const Icon(Icons.brush_rounded),
              ),
              IconButton(
                onPressed: () => setState(strokes.clear),
                icon: const Icon(Icons.undo_rounded),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _StrokePainter extends CustomPainter {
  final List<List<Offset>> strokes;
  final Color color;
  final double width;
  _StrokePainter(this.strokes, this.color, this.width);
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = color
      ..strokeWidth = width
      ..strokeCap = StrokeCap.round;
    for (final line in strokes) {
      for (var i = 1; i < line.length; i++)
        canvas.drawLine(line[i - 1], line[i], p);
    }
  }

  @override
  bool shouldRepaint(covariant _StrokePainter old) => true;
}

class ImagePreviewPage extends StatelessWidget {
  final File file;
  final String title;
  const ImagePreviewPage({super.key, required this.file, required this.title});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(
      child: InteractiveViewer(child: Image.file(file, fit: BoxFit.contain)),
    ),
  );
}

class VideoPreviewPage extends StatefulWidget {
  final File file;
  final String title;
  const VideoPreviewPage({super.key, required this.file, required this.title});
  @override
  State<VideoPreviewPage> createState() => _VideoPreviewPageState();
}

class _VideoPreviewPageState extends State<VideoPreviewPage> {
  late VideoPlayerController player;
  @override
  void initState() {
    super.initState();
    player = VideoPlayerController.file(widget.file)
      ..initialize().then((_) {
        if (mounted) setState(() {});
      });
  }

  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.title),
      actions: [
        IconButton(
          onPressed: () => OpenFilex.open(widget.file.path),
          tooltip: 'Editar com outro aplicativo',
          icon: const Icon(Icons.edit_rounded),
        ),
      ],
    ),
    body: Center(
      child: player.value.isInitialized
          ? Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                AspectRatio(
                  aspectRatio: player.value.aspectRatio,
                  child: VideoPlayer(player),
                ),
                IconButton(
                  iconSize: 48,
                  onPressed: () => setState(
                    () =>
                        player.value.isPlaying ? player.pause() : player.play(),
                  ),
                  icon: Icon(
                    player.value.isPlaying
                        ? Icons.pause_circle
                        : Icons.play_circle,
                  ),
                ),
              ],
            )
          : const CircularProgressIndicator(),
    ),
  );
}

class AudioPreviewPage extends StatefulWidget {
  final File file;
  final String title;
  const AudioPreviewPage({super.key, required this.file, required this.title});
  @override
  State<AudioPreviewPage> createState() => _AudioPreviewPageState();
}

class _AudioPreviewPageState extends State<AudioPreviewPage> {
  final audio = AudioPlayer();
  bool playing = false;
  Duration position = Duration.zero, duration = Duration.zero;
  @override
  void initState() {
    super.initState();
    audio.onPositionChanged.listen((v) {
      if (mounted) setState(() => position = v);
    });
    audio.onDurationChanged.listen((v) {
      if (mounted) setState(() => duration = v);
    });
  }

  @override
  void dispose() {
    audio.dispose();
    super.dispose();
  }

  Future<void> toggle() async {
    if (playing) {
      await audio.pause();
    } else {
      await audio.play(DeviceFileSource(widget.file.path));
    }
    if (mounted) setState(() => playing = !playing);
  }

  String time(Duration d) =>
      '${d.inMinutes.remainder(60).toString().padLeft(2, '0')}:${d.inSeconds.remainder(60).toString().padLeft(2, '0')}';
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis),
    ),
    body: Padding(
      padding: const EdgeInsets.all(26),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 230,
            height: 230,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(28),
              gradient: const LinearGradient(
                colors: [Color(0xFF13B8A6), Color(0xFF263A73)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              boxShadow: [
                BoxShadow(color: teal.withValues(alpha: .3), blurRadius: 30),
              ],
            ),
            child: const Icon(
              Icons.graphic_eq_rounded,
              size: 110,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 28),
          Text(
            widget.title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 20),
          Slider(
            value: duration.inMilliseconds == 0
                ? 0
                : position.inMilliseconds
                      .clamp(0, duration.inMilliseconds)
                      .toDouble(),
            max: duration.inMilliseconds == 0
                ? 1
                : duration.inMilliseconds.toDouble(),
            onChanged: (v) => audio.seek(Duration(milliseconds: v.round())),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [Text(time(position)), Text(time(duration))],
          ),
          const SizedBox(height: 14),
          IconButton.filled(
            onPressed: toggle,
            iconSize: 54,
            icon: Icon(
              playing ? Icons.pause_rounded : Icons.play_arrow_rounded,
            ),
          ),
          const SizedBox(height: 20),
          const Text(
            'Reprodução local · VaultFile',
            style: TextStyle(color: Color(0xFF718087)),
          ),
        ],
      ),
    ),
  );
}

class HtmlPreviewPage extends StatefulWidget {
  final String title, html;
  const HtmlPreviewPage({super.key, required this.title, required this.html});
  @override
  State<HtmlPreviewPage> createState() => _HtmlPreviewPageState();
}

class _HtmlPreviewPageState extends State<HtmlPreviewPage> {
  late final WebViewController controller;
  @override
  void initState() {
    super.initState();
    controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadHtmlString(widget.html);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Prévia · ${widget.title}'),
      actions: [
        IconButton(
          onPressed: () => controller.reload(),
          icon: const Icon(Icons.refresh_rounded),
        ),
      ],
    ),
    body: WebViewWidget(controller: controller),
  );
}

class RemoteAccount {
  String name, host, port, user, pass;
  bool tls;
  RemoteAccount({
    required this.name,
    this.host = '',
    this.port = '21',
    this.user = '',
    this.pass = '',
    this.tls = false,
  });
  Map<String, dynamic> toJson() => {
    'name': name,
    'host': host,
    'port': port,
    'user': user,
    'pass': pass,
    'tls': tls,
  };
  factory RemoteAccount.fromJson(Map<String, dynamic> j) => RemoteAccount(
    name: j['name'] ?? 'Conta',
    host: j['host'] ?? '',
    port: j['port'] ?? '21',
    user: j['user'] ?? '',
    pass: j['pass'] ?? '',
    tls: j['tls'] ?? false,
  );
}

class ConnectionsPage extends StatefulWidget {
  const ConnectionsPage({super.key});
  @override
  State<ConnectionsPage> createState() => _ConnectionsPageState();
}

class _ConnectionsPageState extends State<ConnectionsPage> {
  final ftp = <RemoteAccount>[];
  bool loading = true;
  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final p = await SharedPreferences.getInstance();
    final list = (p.getStringList('ftp_accounts') ?? [])
        .map((x) => RemoteAccount.fromJson(jsonDecode(x)))
        .toList();
    if (mounted)
      setState(() {
        ftp
          ..clear()
          ..addAll(list);
        loading = false;
      });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setStringList(
      'ftp_accounts',
      ftp.map((x) => jsonEncode(x.toJson())).toList(),
    );
  }

  void _toast(String s) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));
  Future<void> _add() async {
    if (ftp.length >= 10) {
      _toast('Limite de 10 contas FTP/FTPS atingido.');
      return;
    }
    final a = await showDialog<RemoteAccount>(
      context: context,
      builder: (_) => const AccountDialog(),
    );
    if (a != null) {
      setState(() => ftp.add(a));
      await _save();
    }
  }

  Future<void> _remove(int i) async {
    setState(() => ftp.removeAt(i));
    await _save();
  }

  @override
  Widget build(BuildContext context) {
    if (loading)
      return const SafeArea(child: Center(child: CircularProgressIndicator()));
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(22, 24, 22, 28),
        children: [
          const Text(
            'Conexões externas',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 6),
          const Text(
            'Contas FTP e FTPS salvas neste dispositivo · até 10 contas.',
            style: TextStyle(color: Color(0xFF6D7B80)),
          ),
          const SizedBox(height: 22),
          Row(
            children: [
              const Icon(Icons.dns_rounded, color: teal),
              const SizedBox(width: 9),
              const Expanded(
                child: Text(
                  'FTP / FTPS',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
              ),
              IconButton(
                onPressed: _add,
                icon: const Icon(Icons.add_circle_rounded, color: teal),
              ),
            ],
          ),
          const SizedBox(height: 8),
          if (ftp.isEmpty)
            const Card(
              child: ListTile(
                leading: Icon(Icons.add_link_rounded, color: teal),
                title: Text('Nenhuma conta adicionada'),
                subtitle: Text('Toque no + para cadastrar'),
              ),
            ),
          ...ftp.asMap().entries.map((entry) {
            final a = entry.value;
            return Card(
              child: ListTile(
                onTap: () => showDialog(
                  context: context,
                  builder: (_) => TestConnectionDialog(account: a),
                ),
                leading: const CircleAvatar(
                  backgroundColor: Color(0xFFDDF6F1),
                  child: Icon(Icons.dns_rounded, color: teal),
                ),
                title: Text(
                  a.name,
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
                subtitle: Text(
                  '${a.host}:${a.port} · ${a.tls ? 'FTPS' : 'FTP'}',
                ),
                trailing: PopupMenuButton<String>(
                  onSelected: (v) {
                    if (v == 'delete') _remove(entry.key);
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 'delete', child: Text('Remover')),
                  ],
                ),
              ),
            );
          }),
        ],
      ),
    );
  }
}

class AccountDialog extends StatefulWidget {
  const AccountDialog({super.key});
  @override
  State<AccountDialog> createState() => _AccountDialogState();
}

class _AccountDialogState extends State<AccountDialog> {
  final name = TextEditingController(),
      host = TextEditingController(),
      port = TextEditingController(text: '21'),
      user = TextEditingController(),
      pass = TextEditingController();
  bool tls = false;
  @override
  Widget build(BuildContext context) => AlertDialog(
    title: const Text('Nova conta FTP / FTPS'),
    content: SingleChildScrollView(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: name,
            decoration: const InputDecoration(labelText: 'Nome da conta'),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: host,
                  decoration: const InputDecoration(labelText: 'IP ou domínio'),
                ),
              ),
              const SizedBox(width: 10),
              SizedBox(
                width: 82,
                child: TextField(
                  controller: port,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Porta'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: user,
                  decoration: const InputDecoration(labelText: 'Usuário'),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: TextField(
                  controller: pass,
                  obscureText: true,
                  decoration: const InputDecoration(labelText: 'Senha'),
                ),
              ),
            ],
          ),
          SwitchListTile(
            contentPadding: EdgeInsets.zero,
            value: tls,
            onChanged: (v) => setState(() => tls = v),
            title: const Text('FTPS seguro'),
            subtitle: Text(tls ? 'Porta recomendada: 990' : 'FTP padrão: 21'),
          ),
        ],
      ),
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Cancelar'),
      ),
      FilledButton(
        onPressed: () {
          if (name.text.trim().isEmpty || host.text.trim().isEmpty) return;
          Navigator.pop(
            context,
            RemoteAccount(
              name: name.text.trim(),
              host: host.text.trim(),
              port: port.text.trim().isEmpty
                  ? (tls ? '990' : '21')
                  : port.text.trim(),
              user: user.text.trim(),
              pass: pass.text,
              tls: tls,
            ),
          );
        },
        child: const Text('Salvar'),
      ),
    ],
  );
}

class TestConnectionDialog extends StatefulWidget {
  final RemoteAccount account;
  const TestConnectionDialog({super.key, required this.account});
  @override
  State<TestConnectionDialog> createState() => _TestConnectionDialogState();
}

class _TestConnectionDialogState extends State<TestConnectionDialog> {
  bool busy = false;
  String status = 'Pronto para testar.';
  Future<void> test() async {
    setState(() {
      busy = true;
      status = 'Conectando...';
    });
    try {
      final port =
          int.tryParse(widget.account.port) ?? (widget.account.tls ? 990 : 21);
      final socket = widget.account.tls
          ? await SecureSocket.connect(
              widget.account.host,
              port,
              timeout: const Duration(seconds: 8),
            )
          : await Socket.connect(
              widget.account.host,
              port,
              timeout: const Duration(seconds: 8),
            );
      final greeting = await socket
          .cast<List<int>>()
          .transform(utf8.decoder)
          .transform(const LineSplitter())
          .first
          .timeout(const Duration(seconds: 8));
      socket.write('USER ${widget.account.user}\r\n');
      await socket.flush();
      socket.write('PASS ${widget.account.pass}\r\n');
      await socket.flush();
      await socket.close();
      if (mounted) setState(() => status = 'Conectado: ${greeting.trim()}');
    } catch (e) {
      if (mounted)
        setState(
          () => status =
              'Falha: ${e.toString().replaceFirst('SocketException: ', '')}',
        );
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) => AlertDialog(
    title: Text(widget.account.name),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(
          '${widget.account.host}:${widget.account.port} · ${widget.account.tls ? 'FTPS' : 'FTP'}',
        ),
        const SizedBox(height: 14),
        Text(
          status,
          style: TextStyle(
            color: status.startsWith('Falha') ? Colors.red : teal,
          ),
        ),
      ],
    ),
    actions: [
      TextButton(
        onPressed: () => Navigator.pop(context),
        child: const Text('Fechar'),
      ),
      FilledButton(
        onPressed: busy ? null : test,
        child: Text(busy ? 'Testando...' : 'Testar'),
      ),
    ],
  );
}

class ToolsPage extends StatefulWidget {
  const ToolsPage({super.key});
  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> {
  bool hidden = false;
  String themeName = 'light';
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (mounted)
        setState(() {
          hidden = p.getBool('show_hidden') ?? false;
          themeName = p.getString('theme_name') ?? 'light';
          appTheme.value = themeName;
        });
    });
  }

  Future<void> _setHidden(bool value) async {
    final p = await SharedPreferences.getInstance();
    await p.setBool('show_hidden', value);
    if (mounted) setState(() => hidden = value);
  }

  Future<void> _setTheme(String value) async {
    final p = await SharedPreferences.getInstance();
    await p.setString('theme_name', value);
    if (mounted) setState(() => themeName = value);
    appTheme.value = value;
  }

  @override
  Widget build(BuildContext context) => SafeArea(
    child: ListView(
      padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
      children: [
        const Text(
          'Configurações',
          style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800),
        ),
        const SizedBox(height: 7),
        const Text(
          'Funções e preferências do VaultFile.',
          style: TextStyle(color: Color(0xFF6D7B80)),
        ),
        const SizedBox(height: 22),
        Card(
          color: ink,
          child: const Padding(
            padding: EdgeInsets.all(18),
            child: Text(
              'Gerencie arquivos locais, mídias e conexões FTP/FTPS em um só lugar.',
              style: TextStyle(color: Colors.white, height: 1.4),
            ),
          ),
        ),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          value: hidden,
          onChanged: _setHidden,
          title: const Text(
            'Exibir arquivos ocultos',
            style: TextStyle(fontWeight: FontWeight.w700),
          ),
          subtitle: const Text('Mostra arquivos e pastas iniciados por ponto'),
        ),
        const Divider(),
        const Padding(
          padding: EdgeInsets.only(top: 12, bottom: 8),
          child: Text(
            'Aparência',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
        ),
        Card(
          child: Column(
            children: [
              ListTile(
                leading: const Icon(Icons.palette_outlined, color: teal),
                title: const Text('Tema do aplicativo'),
                subtitle: Text(
                  themeName == 'glass'
                      ? 'Glassmorphism'
                      : themeName == 'dark'
                      ? 'Escuro'
                      : themeName == 'gray'
                      ? 'Cinza'
                      : 'Claro',
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                child: Wrap(
                  spacing: 8,
                  children: [
                    ChoiceChip(
                      label: const Text('Claro'),
                      selected: themeName == 'light',
                      onSelected: (_) => _setTheme('light'),
                    ),
                    ChoiceChip(
                      label: const Text('Cinza'),
                      selected: themeName == 'gray',
                      onSelected: (_) => _setTheme('gray'),
                    ),
                    ChoiceChip(
                      label: const Text('Escuro'),
                      selected: themeName == 'dark',
                      onSelected: (_) => _setTheme('dark'),
                    ),
                    ChoiceChip(
                      label: const Text('Glass'),
                      selected: themeName == 'glass',
                      onSelected: (_) => _setTheme('glass'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        const Padding(
          padding: EdgeInsets.only(top: 18, bottom: 8),
          child: Text(
            'Armazenamento e permissões',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
        ),
        OutlinedButton.icon(
          onPressed: () async {
            await Permission.manageExternalStorage.request();
            await openAppSettings();
          },
          icon: const Icon(Icons.folder_open_rounded),
          label: const Text('Configurar acesso completo'),
        ),
        FilledButton.icon(
          onPressed: () async {
            await [
              Permission.storage,
              Permission.manageExternalStorage,
              Permission.camera,
              Permission.location,
              Permission.photos,
              Permission.videos,
              Permission.audio,
              Permission.notification,
            ].request();
            if (context.mounted)
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Solicitação de permissões concluída.'),
                ),
              );
          },
          icon: const Icon(Icons.security_rounded),
          label: const Text('Solicitar permissões necessárias'),
        ),
        const SizedBox(height: 14),
        const Card(
          child: ListTile(
            leading: Icon(Icons.archive_rounded, color: teal),
            title: Text('Compactação'),
            subtitle: Text(
              'ZIP é criado internamente. RAR e 7Z são abertos por compactadores compatíveis do Android.',
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.share_rounded, color: teal),
            title: Text('Compartilhamento'),
            subtitle: Text(
              'Bluetooth, aplicativos de mensagem, e-mail e outros destinos do Android.',
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.edit_note_rounded, color: teal),
            title: Text('Editor profissional'),
            subtitle: Text(
              'HTML, CSS, JS, PHP, Python, JSON, Markdown e código',
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.video_library_rounded, color: teal),
            title: Text('Edição de fotos e vídeos'),
            subtitle: Text(
              'Visualização interna e abertura com editor externo compatível',
            ),
          ),
        ),
        const Card(
          child: ListTile(
            leading: Icon(Icons.view_module_rounded, color: teal),
            title: Text('Visualização detalhada'),
            subtitle: Text(
              'Tipo, extensão, tamanho, data, caminho e permissões',
            ),
          ),
        ),
      ],
    ),
  );
}
